import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import PostList from './PostList';
import Sidebar from './Sidebar';

function PostListPageLayout() {
  return (
    <Container fluid className="mt-4">
      <Row>
        <Col md={3} className="d-none d-md-block"> {/* Sidebar, hidden on small screens */}
          <Sidebar />
        </Col>
        <Col md={9} xs={12}> {/* Main content area for posts */}
          <PostList />
        </Col>
      </Row>
    </Container>
  );
}

export default PostListPageLayout; 