const express = require('express');
const userRouter = express.Router();
const userController = require('../controllers/userController');

// Registration page
userRouter.get('/register', userController.renderRegisterPage);

// Handle user registration
userRouter.post('/register', userController.register);

// Landing page
userRouter.get('/login', userController.renderLoginPage);

// Handle user logins
userRouter.post('/login', userController.login);

// Logout user
userRouter.get('/logout', userController.logout);

// Get active users (for sidebar)
userRouter.get('/active', userController.getActiveUsers);

// Get user public profile and their posts
userRouter.get('/:userId/profile', userController.getUserProfile);

module.exports = userRouter;