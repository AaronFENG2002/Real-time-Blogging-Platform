const Post = require('./models/post');

exports.checkPostOwnership = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).render('error', {
        error: "This post doesn't exist",
      });
    }
    if (!post.createdBy.equals(req.user._id)) {
      return res.status(403).render('error', {
        error: 'No access to this article',
      });
    }
    req.post = post;
    next();
  } catch (err) {
    res.status(500).render('error', {
      error: 'Server error, please try again later',
    });
  }
};