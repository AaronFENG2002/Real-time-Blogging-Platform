const express = require('express');
const postRouter = express.Router();
const postController = require('../controllers/postController');
const { checkPostOwnership } = require('../userMiddleware');

// New Posts page
postRouter.get('/new',postController.renderNewPostPage);

// Create a new post
postRouter.post('/new',postController.createPost);

// Get All Posts
postRouter.get('/',postController.getAllPosts);

// Get post details
postRouter.get('/:id',postController.getPostById);

// Edit the post page
postRouter.get('/:id/edit',checkPostOwnership,postController.renderEditPostPage);

// Update the post
postRouter.post('/:id/edit',checkPostOwnership,postController.editPost);

// Delete the post
postRouter.post('/:id/delete',checkPostOwnership,postController.deletePost);

module.exports = postRouter;