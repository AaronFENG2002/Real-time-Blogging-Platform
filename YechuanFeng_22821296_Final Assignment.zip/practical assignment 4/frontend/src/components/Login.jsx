import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Form, Button, Alert } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';

function Login({ onLoginSuccess }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchInitialMessage = async () => {
      try {
        // Example: const response = await axios.get('/api/user/login');
        // if(response.data.message) setMessage(response.data.message);
      } catch (err) {
        // console.error("Could not fetch initial login message", err);
      }
    };
    // fetchInitialMessage(); // Uncomment if needed
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');
    setLoading(true);
    try {
      const response = await axios.post('/api/user/login', { username, password });
      if (response.data.user) {
        localStorage.setItem('user', JSON.stringify(response.data.user));
        if (onLoginSuccess) onLoginSuccess();
        navigate('/');
      } else {
        setMessage(response.data.message || 'Login attempt failed.');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed. Please check your credentials.');
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: '400px', margin: 'auto', paddingTop: '20px' }}>
      <h2>Login</h2>
      {message && !error && <Alert variant="info" className="mt-3">{message}</Alert>}
      {error && 
        <Alert variant="danger" onClose={() => setError('')} dismissible className="mt-3">
          {error}
        </Alert>
      }
      <Form onSubmit={handleSubmit} className="mt-3">
        <Form.Group className="mb-3" controlId="formBasicUsername">
          <Form.Label>Username</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter username" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)} 
            required 
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control 
            type="password" 
            placeholder="Password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
        </Form.Group>
        
        <Button variant="primary" type="submit" disabled={loading} block>
          {loading ? 'Logging in...' : 'Login'}
        </Button>
      </Form>
      <div className="mt-3 text-center">
        Don't have an account? <Link to="/register">Register here</Link>
      </div>
    </div>
  );
}

export default Login; 