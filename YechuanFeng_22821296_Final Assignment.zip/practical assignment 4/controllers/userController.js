const passport = require('passport');
const User = require('../models/user');
const Post = require('../models/post'); // Ensure Post model is imported
const { registerSchema, loginSchema} = require('../validation');

// Registration Page
exports.renderRegisterPage = (req, res) => {
  try {
    res.json({
      message: 'Please register.',
    });
  } catch (err) {
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Registered User
exports.register = async (req, res) => {
  const { username, password } = req.body;
  // Validating Input with Joi
  const { error } = registerSchema.validate({ username, password });
  if (error) {
    return res.status(400).json({
      userInput: { username, password },
      error: error.details[0].message,
    });
  }
  try {
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({
        userInput: { username, password },
        error: 'Username already exists',
      });
    }
    const user = new User({ username, password });
    await user.save();
    res.json({
      message: 'Successful registration, please log in',
    });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Login Page
exports.renderLoginPage = (req, res) => {
  try {
    res.json({
      message: 'Please login.',
    });
  } catch (err) {
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// User Login
exports.login = async (req, res, next) => {
  const { username, password } = req.body;
  const { error } = loginSchema.validate({ username, password });
  if (error) {
    return res.status(400).json({
      userInput: { username, password },
      error: error.details[0].message,
    });
  }
  passport.authenticate('local', (err, user, info) => {
    if (err) {
      console.error('Login authentication error:', err);
      return res.status(500).json({
        error: 'Server error, please try again later',
      });
    }
    if (!user) {
      return res.status(401).json({
        userInput: { username, password },
        error: info.message || 'Invalid credentials',
      });
    }
    req.login(user, (err) => {
      if (err) {
        console.error('Req login error:', err);
        return res.status(500).json({
          error: 'Server error during login process',
        });
      }
      // Return a user object that matches what frontend expects (e.g., with _id)
      const userForFrontend = { 
        _id: user._id, 
        username: user.username, 
        isAdmin: user.isAdmin 
      };
      return res.json({ message: 'Login successful', user: userForFrontend });
    });
  })(req, res, next);
};

// Logout User
exports.logout = (req, res) => {
  req.logout((err) => { // req.logout is provided by Passport
    if (err) { 
      console.error("Logout error:", err);
      return res.status(500).json({ error: 'Server error during logout' }); 
    }
    // req.session.destroy(); // Optionally destroy session if not handled by req.logout fully
    res.clearCookie('connect.sid'); // Ensure session cookie is cleared if applicable
    res.json({ message: 'Logout successful' });
  });
};

// Get user public profile and their posts
exports.getUserProfile = async (req, res) => {
  try {
    const userId = req.params.userId;
    const user = await User.findById(userId).select('username _id isAdmin createdAt');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    const posts = await Post.find({ createdBy: userId })
                            .sort({ createdAt: -1 })
                            .populate('createdBy', 'username'); // Populating createdBy for consistency
    res.json({ user, posts });
  } catch (err) {
    console.error('Error fetching user profile:', err);
    if (err.kind === 'ObjectId') {
        return res.status(400).json({ error: 'Invalid user ID format' });
    }
    res.status(500).json({ error: 'Server error, please try again later' });
  }
};

// Get active users (e.g., for a sidebar)
exports.getActiveUsers = async (req, res) => {
  try {
    // This is a placeholder logic. 
    // You might want to define "active" based on recent posts, logins, etc.
    // For now, let's return a few most recently created users who are not admins.
    // Or, if you want to show users who have posted, you could do a distinct on createdBy in Posts.
    const users = await User.find({ isAdmin: { $ne: true } })
                            .sort({ createdAt: -1 })
                            .limit(5) // Limit to 5 users for example
                            .select('username _id'); // Select only public info
    res.json({ users });
  } catch (err) {
    console.error('Error fetching active users:', err);
    res.status(500).json({ error: 'Server error, please try again later' });
  }
};

