import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Form, Button, Container, Card, Alert, Spinner } from 'react-bootstrap';

function CreatePost() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');
    setLoading(true);
    try {
      const response = await axios.post('/api/posts/new', { title, content, tags });
      setMessage(response.data.message || 'Post created successfully!');
      // setError(''); // Clear previous errors
      // Redirect to the new post or post list after a short delay
      setTimeout(() => {
        navigate(`/posts/${response.data.post._id}`); 
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create post. Please check your input.');
      // setMessage(''); // Clear previous success messages
      console.error("Create post error:", err);
    }
    setLoading(false);
  };

  return (
    <Container style={{ maxWidth: '700px', marginTop: '20px' }}>
      <Card>
        <Card.Header as="h2">Create New Post</Card.Header>
        <Card.Body>
          {message && <Alert variant="success">{message}</Alert>}
          {error && <Alert variant="danger" onClose={() => setError('')} dismissible>{error}</Alert>}
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formPostTitle">
              <Form.Label>Title</Form.Label>
              <Form.Control 
                type="text" 
                placeholder="Enter post title" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
                required 
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formPostContent">
              <Form.Label>Content</Form.Label>
              <Form.Control 
                as="textarea" 
                rows={5} 
                placeholder="Write your post content here" 
                value={content} 
                onChange={(e) => setContent(e.target.value)} 
                required 
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formPostTags">
              <Form.Label>Tags (comma-separated)</Form.Label>
              <Form.Control 
                type="text" 
                placeholder="e.g., tech, programming, news" 
                value={tags} 
                onChange={(e) => setTags(e.target.value)} 
              />
            </Form.Group>
            
            <Button variant="primary" type="submit" disabled={loading}>
              {loading ? 
                <><Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /> Creating...</> : 
                'Create Post'}
            </Button>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
}

export default CreatePost; 