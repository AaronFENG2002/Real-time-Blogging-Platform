import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { Container, Card, ListGroup, Spinner, Alert, Row, Col, Button, Badge } from 'react-bootstrap';

function UserProfile() {
  const [profileUser, setProfileUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { userId } = useParams();
  const currentUser = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchUserProfile = async () => {
      setLoading(true);
      setError('');
      try {
        // Assuming an endpoint like /api/user/:userId/profile which returns user info and their posts
        const response = await axios.get(`/api/user/${userId}/profile`);
        setProfileUser(response.data.user); // Assuming user object with username, _id, etc.
        setPosts(response.data.posts);     // Assuming array of posts by this user
      } catch (err) {
        setError('Failed to fetch user profile. The user may not exist or there was a server error.');
        console.error("Fetch user profile error:", err);
      }
      setLoading(false);
    };

    if (userId) {
      fetchUserProfile();
    }
  }, [userId]);

  // Placeholder for subscribe functionality
  const handleSubscribe = () => {
    alert(`Subscribing to ${profileUser?.username} (feature not implemented yet).`);
  };

  if (loading) {
    return (
      <Container className="text-center mt-5">
        <Spinner animation="border" /> <p>Loading user profile...</p>
      </Container>
    );
  }

  if (error) {
    return <Container className="mt-3"><Alert variant="danger">{error}</Alert></Container>;
  }

  if (!profileUser) {
    return <Container className="mt-3"><Alert variant="warning">User profile not found.</Alert></Container>;
  }

  const canEditOrDelete = currentUser && currentUser._id === profileUser._id;

  return (
    <Container className="mt-4">
      <Card className="mb-4">
        <Card.Header as="h2">
          {profileUser.username}'s Profile 
          {currentUser && currentUser._id !== profileUser._id && (
             <Button variant="outline-info" size="sm" className="ms-2" onClick={handleSubscribe}>
               Subscribe
             </Button>
          )}
        </Card.Header>
        <Card.Body>
          <Card.Text>Total posts: {posts.length}</Card.Text>
          {/* Add more profile info here if available */}
        </Card.Body>
      </Card>

      <h3>Posts by {profileUser.username}</h3>
      {posts.length > 0 ? (
        <ListGroup variant="flush">
          {posts.map(post => (
            <ListGroup.Item key={post._id} className="p-0 mb-2">
              <Card>
                <Card.Body>
                  <Card.Title><Link to={`/posts/${post._id}`}>{post.title}</Link></Card.Title>
                  {post.tags && post.tags.length > 0 && (
                    <div className="mb-2">
                      {post.tags.map(tag => <Badge bg="secondary" key={tag} className="me-1">{tag}</Badge>)}
                    </div>
                  )}
                  <Card.Text className="text-muted">Created: {new Date(post.createdAt).toLocaleDateString()}</Card.Text>
                  {canEditOrDelete && (
                    <div className="mt-2">
                      <Button as={Link} to={`/posts/${post._id}/edit`} variant="outline-primary" size="sm" className="me-2">Edit</Button>
                      {/* Delete button would need a confirmation modal like in PostDetail */}
                      <Button variant="outline-danger" size="sm" onClick={() => alert('Delete post feature for profile page not fully implemented.')}>Delete</Button>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </ListGroup.Item>
          ))}
        </ListGroup>
      ) : (
        <Alert variant="info">This user has not posted anything yet.</Alert>
      )}
    </Container>
  );
}

export default UserProfile; 