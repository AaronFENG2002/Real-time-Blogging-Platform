import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Container, Card, Button, Form, Spinner, Alert, ListGroup, Row, Col, Modal, Badge } from 'react-bootstrap';

function AdminPostList() {
  const [posts, setPosts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [postToDelete, setPostToDelete] = useState(null);

  const fetchPosts = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get(`/api/admin/allPosts?search=${searchTerm}`);
      setPosts(response.data.posts);
    } catch (err) {
      setError('Failed to fetch posts. Please try again later.');
      console.error("Fetch admin posts error:", err);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchPosts();
  }, [searchTerm]);

  const handleDeleteInitiate = (post) => {
    setPostToDelete(post);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = async () => {
    if (!postToDelete) return;
    try {
      await axios.post(`/api/admin/posts/${postToDelete._id}/delete`);
      setShowDeleteModal(false);
      setPostToDelete(null);
      fetchPosts(); // Refresh the list
      // alert('Post deleted successfully by admin'); // Optional: use a toast notification
    } catch (err) {
      setError(`Failed to delete post "${postToDelete.title}". Please try again.`);
      console.error("Admin delete post error:", err);
      setShowDeleteModal(false); // Still close modal on error
      setPostToDelete(null);
    }
  };

  return (
    <Container fluid>
      <Card>
        <Card.Header as="h2">Admin: All Posts Management</Card.Header>
        <Card.Body>
          <Form className="mb-3">
            <Form.Control 
              type="text" 
              placeholder="Search posts by title or tags..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Form>

          {loading && (
            <div className="text-center">
              <Spinner animation="border" /> <p>Loading posts...</p>
            </div>
          )}
          {error && <Alert variant="danger" onClose={() => setError('')} dismissible>{error}</Alert>}
          {!loading && !error && posts.length === 0 && <Alert variant="info">No posts found.</Alert>}

          {!loading && !error && posts.length > 0 && (
            <ListGroup variant="flush">
              {posts.map(post => (
                <ListGroup.Item key={post._id}>
                  <Row className="align-items-center">
                    <Col md={8}>
                      <h5><Link to={`/posts/${post._id}`}>{post.title}</Link></h5>
                      <small className="text-muted">By: {post.createdBy?.username || 'Unknown'} | Tags: {post.tags && post.tags.length > 0 ? post.tags.map(tag => <Badge bg="light" text="dark" key={tag} className="me-1">{tag}</Badge>) : 'None'}</small>
                    </Col>
                    <Col md={4} className="text-md-end">
                      <Button variant="outline-danger" size="sm" onClick={() => handleDeleteInitiate(post)}>
                        Delete Post
                      </Button>
                    </Col>
                  </Row>
                </ListGroup.Item>
              ))}
            </ListGroup>
          )}
        </Card.Body>
      </Card>

      {postToDelete && (
        <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Deletion</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            Are you sure you want to delete the post titled "<strong>{postToDelete.title}</strong>"?
            This action cannot be undone.
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleDeleteConfirm}>
              Delete Post
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </Container>
  );
}

export default AdminPostList; 