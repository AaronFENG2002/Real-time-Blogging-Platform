import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Card, Button, Form, Container, Row, Col, Spinner, Alert } from 'react-bootstrap';

function PostList() {
  const [posts, setPosts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoading(true);
        setError('');
        const response = await axios.get(`/api/posts?search=${searchTerm}`);
        setPosts(response.data.posts);
      } catch (err) {
        setError('Failed to fetch posts. Please try again later.');
        console.error("Fetch posts error:", err);
      }
      setLoading(false);
    };
    fetchPosts();
  }, [searchTerm]);

  return (
    <Container fluid>
      <Row className="justify-content-between align-items-center mb-3">
        <Col md={8}>
          <h2>All Posts</h2>
        </Col>
        <Col md={4} className="text-md-end">
          <Button as={Link} to="/posts/new" variant="success">Create New Post</Button>
        </Col>
      </Row>
      <Form className="mb-3">
        <Form.Control 
          type="text" 
          placeholder="Search posts by title or tags..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </Form>

      {loading && (
        <div className="text-center">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
          <p>Loading posts...</p>
        </div>
      )}
      {error && <Alert variant="danger">{error}</Alert>}
      {!loading && !error && posts.length === 0 && <Alert variant="info">No posts found.</Alert>}
      
      <Row xs={1} md={2} lg={3} className="g-4">
        {!loading && !error && posts.map(post => (
          <Col key={post._id}>
            <Card className="h-100">
              <Card.Body className="d-flex flex-column">
                <Card.Title>
                  <Link to={`/posts/${post._id}`} style={{ textDecoration: 'none' }}>{post.title}</Link>
                </Card.Title>
                <Card.Subtitle className="mb-2 text-muted">
                  By: {post.createdBy?.username || 'Unknown'}
                </Card.Subtitle>
                {post.tags && post.tags.length > 0 && (
                  <Card.Text>
                    Tags: {post.tags.join(', ')}
                  </Card.Text>
                )}
                {/* <Card.Text className="flex-grow-1">{post.content.substring(0, 100)}...</Card.Text> */}
                <Link to={`/posts/${post._id}`} className="mt-auto btn btn-outline-primary btn-sm">Read More</Link>
              </Card.Body>
              <Card.Footer>
                <small className="text-muted">Created: {new Date(post.createdAt).toLocaleDateString()}</small>
              </Card.Footer>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
}

export default PostList; 