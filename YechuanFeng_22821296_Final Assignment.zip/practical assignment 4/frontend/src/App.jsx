import React, { useState, useEffect } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  Navigate,
  useNavigate
} from 'react-router-dom';
import { Navbar, Nav, Container, NavDropdown } from 'react-bootstrap';
import Register from './components/Register';
import Login from './components/Login';
import PostListPageLayout from './components/PostListPageLayout';
import CreatePost from './components/CreatePost';
import PostDetail from './components/PostDetail';
import EditPost from './components/EditPost';
import AdminUserList from './components/AdminUserList';
import AdminPostList from './components/AdminPostList';
import UserProfile from './components/UserProfile';
import './App.css';
import axios from 'axios';

// Helper for protected routes
const ProtectedRoute = ({ children }) => {
  const user = JSON.parse(localStorage.getItem('user'));
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const AdminRoute = ({ children }) => {
  const user = JSON.parse(localStorage.getItem('user'));
  if (!user || !user.isAdmin) {
    // You could show a message here if desired, e.g., using react-toastify or a simple alert
    return <Navigate to="/" replace />;
  }
  return children;
};

function App() {
  const [currentUser, setCurrentUser] = useState(JSON.parse(localStorage.getItem('user')));
  const navigateHook = useNavigate(); // For programmatic navigation after logout

  // Effect to update currentUser when localStorage changes (e.g. login/logout in other tabs)
  useEffect(() => {
    const handleStorageChange = () => {
      setCurrentUser(JSON.parse(localStorage.getItem('user')));
    };
    window.addEventListener('storage', handleStorageChange);
    // Also update on component mount in case of direct navigation or refresh
    setCurrentUser(JSON.parse(localStorage.getItem('user'))); 
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const handleLogout = async () => {
    try {
      await axios.get('/api/user/logout'); 
      localStorage.removeItem('user');
      setCurrentUser(null);
      navigateHook('/login'); // Navigate to login page after logout
    } catch (error) {
      console.error('Logout failed', error);
      // Handle logout error (e.g., show a notification)
    }
  };
  
  const handleLoginSuccess = () => {
    setCurrentUser(JSON.parse(localStorage.getItem('user')));
    // navigateHook('/'); // Optionally navigate to home after login
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      <Navbar bg="dark" variant="dark" expand="lg" collapseOnSelect sticky="top">
        <Container>
          <Navbar.Brand as={Link} to="/">My Blog App</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link as={Link} to="/" eventKey="1">Home</Nav.Link>
              <Nav.Link as={Link} to="/posts" eventKey="2">All Posts</Nav.Link>
              {currentUser && (
                <Nav.Link as={Link} to="/posts/new" eventKey="3">Create Post</Nav.Link>
              )}
            </Nav>
            <Nav>
              {currentUser ? (
                <NavDropdown title={`Hi, ${currentUser.username}`} id="user-nav-dropdown">
                  <NavDropdown.Item as={Link} to={`/user/${currentUser._id}/profile`} eventKey="profile">My Profile</NavDropdown.Item>
                  {currentUser.isAdmin && (
                    <>
                      <NavDropdown.Divider />
                      <NavDropdown.Header>Admin Tools</NavDropdown.Header>
                      <NavDropdown.Item as={Link} to="/admin/users" eventKey="admin.1">Manage Users</NavDropdown.Item>
                      <NavDropdown.Item as={Link} to="/admin/posts" eventKey="admin.2">Manage Posts</NavDropdown.Item>
                    </>
                  )}
                  <NavDropdown.Divider />
                  <NavDropdown.Item onClick={handleLogout} eventKey="4">Logout</NavDropdown.Item>
                </NavDropdown>
              ) : (
                <>
                  <Nav.Link as={Link} to="/register" eventKey="5">Register</Nav.Link>
                  <Nav.Link as={Link} to="/login" eventKey="6">Login</Nav.Link>
                </>
              )}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <main className="flex-grow-1">
        <Routes>
          <Route path="/register" element={<Container className="mt-4"><Register /></Container>} />
          <Route path="/login" element={<Container className="mt-4"><Login onLoginSuccess={handleLoginSuccess} /></Container>} /> 
          
          <Route path="/posts" element={<PostListPageLayout />} /> 
          
          <Route path="/posts/new" element={<ProtectedRoute><Container className="mt-4"><CreatePost /></Container></ProtectedRoute>} />
          <Route path="/posts/:id" element={<Container className="mt-4"><PostDetail /></Container>} />
          <Route path="/posts/:id/edit" element={<ProtectedRoute><Container className="mt-4"><EditPost /></Container></ProtectedRoute>} />
          
          <Route path="/user/:userId/profile" element={<UserProfile />} />
          
          <Route path="/admin/users" element={<AdminRoute><Container className="mt-4"><AdminUserList /></Container></AdminRoute>} />
          <Route path="/admin/posts" element={<AdminRoute><Container className="mt-4"><AdminPostList /></Container></AdminRoute>} />
          
          <Route path="/" element={<Container className="mt-4"><h2>Home - Welcome, {currentUser ? currentUser.username : 'Guest'}!</h2></Container>} />
          <Route path="*" element={<Navigate to="/" replace />} /> 
        </Routes>
      </main>
      
      <footer className="bg-dark text-white text-center site-footer">
        My Blog App ©{new Date().getFullYear()} - Powered by React-Bootstrap
      </footer>
    </div>
  );
}

// To use useNavigate hook inside App, App itself cannot be the one rendering Router.
// So we create a wrapper.
const AppWrapper = () => (
  <Router>
    <App />
  </Router>
);

export default AppWrapper;
