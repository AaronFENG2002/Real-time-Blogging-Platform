const Joi = require('joi');

// Registration form validation
const registerSchema = Joi.object({
  username: Joi.string().required().messages({
    'string.empty': 'Username is required',
  }),
  password: Joi.string().min(6).required().messages({
    'string.empty': 'Password is required',
    'string.min': 'Password needs to be at least 6 characters',
  }),
});

// Login Form Validation
const loginSchema = Joi.object({
  username: Joi.string().required().messages({
    'string.empty': 'Username is required',
  }),
  password: Joi.string().required().messages({
    'string.empty': 'Password is required',
  }),
});

// Blog Post Form Validation
const postSchema = Joi.object({
  title: Joi.string().required().messages({
    'string.empty': 'Title is required',
  }),
  content: Joi.string().required().messages({
    'string.empty': 'Content is required',
  }),
  tags: Joi.string().required().messages({
    'string.empty': 'Tags are required',
  }),
});

module.exports = { registerSchema, loginSchema, postSchema };