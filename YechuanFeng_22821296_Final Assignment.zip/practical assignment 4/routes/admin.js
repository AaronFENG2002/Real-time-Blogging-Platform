const express = require('express');
const adminRouter = express.Router();
const adminController = require('../controllers/adminController');
const { isAdmin } = require('../isAdmin'); 

// View all users
adminRouter.get('/allUsers', isAdmin, adminController.viewAllUsers);

// View all posts
adminRouter.get('/allPosts', isAdmin, adminController.viewAllPosts);

// Delete the post
adminRouter.post('/posts/:id/delete', isAdmin, adminController.deletePost);

module.exports = adminRouter;

