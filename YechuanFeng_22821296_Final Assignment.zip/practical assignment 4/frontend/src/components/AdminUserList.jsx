import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, ListGroup, Form, Spinner, Alert, Card, Badge } from 'react-bootstrap';

function AdminUserList() {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await axios.get(`/api/admin/allUsers?search=${searchTerm}`);
        setUsers(response.data.users);
      } catch (err) {
        setError('Failed to fetch users. Please try again later.');
        console.error("Fetch admin users error:", err);
      }
      setLoading(false);
    };
    fetchUsers();
  }, [searchTerm]);

  return (
    <Container fluid>
      <Card>
        <Card.Header as="h2">Admin: All Users</Card.Header>
        <Card.Body>
          <Form className="mb-3">
            <Form.Control 
              type="text" 
              placeholder="Search users by username..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Form>

          {loading && (
            <div className="text-center">
              <Spinner animation="border" /> <p>Loading users...</p>
            </div>
          )}
          {error && <Alert variant="danger">{error}</Alert>}
          {!loading && !error && users.length === 0 && <Alert variant="info">No users found.</Alert>}
          
          {!loading && !error && users.length > 0 && (
            <ListGroup variant="flush">
              {users.map(user => (
                <ListGroup.Item key={user._id} className="d-flex justify-content-between align-items-start">
                  <div>
                    <strong>{user.username}</strong>
                  </div>
                  <Badge bg={user.isAdmin ? 'success' : 'secondary'} pill>
                    {user.isAdmin ? 'Admin' : 'User'}
                  </Badge>
                  {/* Potential actions: Edit role, Delete user - would require modals and API endpoints */}
                </ListGroup.Item>
              ))}
            </ListGroup>
          )}
        </Card.Body>
      </Card>
    </Container>
  );
}

export default AdminUserList; 