import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ListGroup, Spinner, Alert, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

function Sidebar() {
  const [activeUsers, setActiveUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchActiveUsers = async () => {
      setLoading(true);
      setError('');
      try {
        // Assuming an endpoint like /api/users/active
        const response = await axios.get('/api/users/active'); 
        setActiveUsers(response.data.users); // Assuming it returns an array of user objects
      } catch (err) {
        setError('Failed to fetch active users.');
        console.error("Fetch active users error:", err);
      }
      setLoading(false);
    };
    fetchActiveUsers();
  }, []);

  return (
    <Card>
      <Card.Header as="h5">Active Users</Card.Header>
      <Card.Body>
        {loading && <div className="text-center"><Spinner animation="border" size="sm" /> <small>Loading...</small></div>}
        {error && <Alert variant="warning" size="sm">{error}</Alert>}
        {!loading && !error && activeUsers.length === 0 && <small>No active users to show right now.</small>}
        {!loading && !error && activeUsers.length > 0 && (
          <ListGroup variant="flush">
            {activeUsers.map(user => (
              <ListGroup.Item key={user._id} action as={Link} to={`/user/${user._id}/profile`}>
                {user.username} {/* Assuming user object has a username property */}
              </ListGroup.Item>
            ))}
          </ListGroup>
        )}
      </Card.Body>
    </Card>
  );
}

export default Sidebar; 