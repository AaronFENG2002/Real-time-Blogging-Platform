import React, { useState } from 'react';
import axios from 'axios';
import { Form, Button, Alert } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';

function Register() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');
    setLoading(true);
    try {
      const response = await axios.post('/api/user/register', { username, password });
      setMessage(response.data.message || 'Registration successful! Please login.');
      // Optionally navigate to login page after a delay or let user click
      setTimeout(() => {
        navigate('/login');
      }, 2000); // Navigate after 2 seconds
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: '400px', margin: 'auto', paddingTop: '20px' }}>
      <h2>Register</h2>
      {message && !error && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && 
        <Alert variant="danger" onClose={() => setError('')} dismissible className="mt-3">
          {error}
        </Alert>
      }
      <Form onSubmit={handleSubmit} className="mt-3">
        <Form.Group className="mb-3" controlId="formRegisterUsername">
          <Form.Label>Username</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Choose a username" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)} 
            required 
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formRegisterPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control 
            type="password" 
            placeholder="Choose a password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
          {/* You might want to add a password confirmation field here */}
        </Form.Group>
        
        <Button variant="primary" type="submit" disabled={loading} block>
          {loading ? 'Registering...' : 'Register'}
        </Button>
      </Form>
      <div className="mt-3 text-center">
        Already have an account? <Link to="/login">Login here</Link>
      </div>
    </div>
  );
}

export default Register; 