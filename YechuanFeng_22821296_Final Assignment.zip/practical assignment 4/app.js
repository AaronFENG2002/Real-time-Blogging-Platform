const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const passport = require('./passport');
const session = require('express-session');
const flash = require('connect-flash');
const path = require('path');
const cors = require('cors');

dotenv.config();

const userRoutes = require('./routes/user');
const postRoutes = require('./routes/post'); 
const adminRoutes = require('./routes/admin');
const app = express();

// CORS 配置
app.use(cors({
  origin: 'http://localhost:5173', // 允许来自 Vite 开发服务器的请求
  credentials: true // 允许发送凭据 (例如 cookies)
}));

// Middleware: Parsing JSON and form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB Atlas'))
  .catch(err => console.error('❌ Connection error:', err));

// Configure the session
app.use(
  session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: false,
  })
);

// Initialize the Passport.js
app.use(passport.initialize());
app.use(passport.session());

// Configure Flash messages
app.use(flash());

// Global middleware: Passes Flash messages and user information to the view
app.use((req, res, next) => {
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  res.locals.user = req.user || null;
  next();
});

// Configure a static file directory
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/user', userRoutes);
app.use('/posts', postRoutes);
app.use('/admin', adminRoutes);

// Root route
app.get('/', (req, res) => {
  res.redirect('/posts');
});

app.set('view engine', 'pug');
app.set('views', './views');

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀Server running on http://localhost:${PORT}`));