const Post = require('../models/post');
const {postSchema} = require('../validation');

// New Posts Page
exports.renderNewPostPage = (req, res) => {
  try {
    res.json({
      message: 'Create a new post.',
    });
  } catch (err) {
    console.error("Error in renderNewPostPage:", err);
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Create new post
exports.createPost = async (req, res) => {
  const { title, content, tags } = req.body;
  const { error } = postSchema.validate({ title, content, tags });
  if (error) {
    return res.status(400).json({
      post: { title, content, tags }, 
      error: error.details[0].message,
    });
  }

  try {
    console.log('Current user for createPost:', req.user);
    if (!req.user || !req.user._id) {
      console.error('User not authenticated or user ID missing for createPost');
      return res.status(401).json({
        error: 'User not authenticated. Please login to create a post.',
      });
    }

    const post = new Post({
      title,
      content,
      tags: tags ? tags.split(',').map(tag => tag.trim()) : [],
      createdBy: req.user._id,
    });
    await post.save();
    res.status(201).json({ message: 'Post created successfully', post });
  } catch (err) {
    console.error("Error creating post in postController:", err);
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Get all posts
exports.getAllPosts = async (req, res) => {
  const searchTerm = req.query.search || '';
  const filter = searchTerm
    ? {
        $or: [
          { title: { $regex: searchTerm, $options: 'i' } },
          { tags: { $regex: searchTerm, $options: 'i' } },
        ],
      }
    : {};
  try {
    const posts = await Post.find(filter).populate('createdBy', 'username').sort({ createdAt: -1 });
    res.json({ posts, searchTerm });
  } catch (err) {
    console.error("Error in getAllPosts:", err);
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Get post details
exports.getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('createdBy', 'username _id');
    if (!post) {
      return res.status(404).json({ error: 'Corresponding post not found' });
    }
    res.json({ post });
  } catch (err) {
    console.error("Error in getPostById:", err);
    if (err.kind === 'ObjectId') {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Edit Post Page
exports.renderEditPostPage = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
        return res.status(404).json({ error: 'Post not found' });
    }
    post.tags = Array.isArray(post.tags) ? post.tags.join(', ') : '';
    res.json({
      post,
    });
  } catch (err) {
    console.error("Error in renderEditPostPage:", err);
    if (err.kind === 'ObjectId') {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

exports.editPost = async (req, res) => {
  const { title, content, tags } = req.body;
  const { error } = postSchema.validate({ title, content, tags });
  if (error) {
    return res.status(400).json({
      post: { title, content, tags}, 
      error: error.details[0].message,
    });
  }
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
        return res.status(404).json({ error: 'Post not found' });
    }
    if (post.createdBy.toString() !== req.user._id.toString() && !req.user.isAdmin) {
        return res.status(403).json({ error: 'User not authorized to edit this post' });
    }

    post.title = title;
    post.content = content;
    post.tags = tags ? tags.split(',').map(tag => tag.trim()) : [];
    await post.save();
    res.json({ message: 'Post updated successfully', post });
  } catch (err) {
    console.error("Error in editPost:", err);
    if (err.kind === 'ObjectId') {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Delete post
exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
        return res.status(404).json({ error: 'Post not found' });
    }
    if (post.createdBy.toString() !== req.user._id.toString() && !req.user.isAdmin) {
        return res.status(403).json({ error: 'User not authorized to delete this post' });
    }
    await post.deleteOne();
    res.json({ message: 'Post successfully deleted' });
  } catch (err) {
    console.error("Error in deletePost:", err);
    if (err.kind === 'ObjectId') {
        return res.status(400).json({ error: 'Invalid post ID format' });
    }
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};