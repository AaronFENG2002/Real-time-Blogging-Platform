import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Form, Button, Container, Card, Alert, Spinner } from 'react-bootstrap';

function EditPost() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loadingData, setLoadingData] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPostData = async () => {
      setLoadingData(true);
      try {
        const response = await axios.get(`/api/posts/${id}/edit`); 
        const post = response.data.post;
        if (post) {
          setTitle(post.title);
          setContent(post.content);
          setTags(Array.isArray(post.tags) ? post.tags.join(', ') : '');
        } else {
          setError('Post not found or unable to load data for editing.');
        }
      } catch (err) {
        setError('Failed to load post data for editing. Please try again.');
        console.error("Fetch post for edit error:", err);
      }
      setLoadingData(false);
    };
    fetchPostData();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');
    setSubmitting(true);
    try {
      const response = await axios.post(`/api/posts/${id}/edit`, { title, content, tags });
      setMessage(response.data.message || 'Post updated successfully!');
      setTimeout(() => {
        navigate(`/posts/${id}`); 
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to update post. Please check your input.');
      console.error("Update post error:", err);
    }
    setSubmitting(false);
  };

  if (loadingData) {
    return (
      <Container className="text-center mt-5">
        <Spinner animation="border" />
        <p>Loading post details...</p>
      </Container>
    );
  }

  return (
    <Container style={{ maxWidth: '700px', marginTop: '20px' }}>
      <Card>
        <Card.Header as="h2">Edit Post</Card.Header>
        <Card.Body>
          {message && <Alert variant="success">{message}</Alert>}
          {error && <Alert variant="danger" onClose={() => setError('')} dismissible>{error}</Alert>}
          {!title && !loadingData && !error && <Alert variant="warning">Could not load post data. <Link to="/posts">Go back to posts.</Link></Alert>} 
          
          {title && (
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3" controlId="formEditPostTitle">
                <Form.Label>Title</Form.Label>
                <Form.Control 
                  type="text" 
                  placeholder="Enter post title" 
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)} 
                  required 
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formEditPostContent">
                <Form.Label>Content</Form.Label>
                <Form.Control 
                  as="textarea" 
                  rows={5} 
                  placeholder="Write your post content here" 
                  value={content} 
                  onChange={(e) => setContent(e.target.value)} 
                  required 
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formEditPostTags">
                <Form.Label>Tags (comma-separated)</Form.Label>
                <Form.Control 
                  type="text" 
                  placeholder="e.g., tech, programming, news" 
                  value={tags} 
                  onChange={(e) => setTags(e.target.value)} 
                />
              </Form.Group>
              
              <Button variant="primary" type="submit" disabled={submitting} className="me-2">
                {submitting ? 
                  <><Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" /> Updating...</> : 
                  'Update Post'}
              </Button>
              <Button variant="secondary" onClick={() => navigate(`/posts/${id}`)} disabled={submitting}>
                Cancel
              </Button>
            </Form>
          )}
        </Card.Body>
      </Card>
    </Container>
  );
}

export default EditPost; 