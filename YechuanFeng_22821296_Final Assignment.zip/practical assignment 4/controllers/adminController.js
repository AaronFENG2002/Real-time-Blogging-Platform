const User = require('../models/user');
const Post = require('../models/post');

// View all users
exports.viewAllUsers = async (req, res) => {
  const searchTerm = req.query.search || ''; 
  const filter = searchTerm
    ? { username: { $regex: searchTerm, $options: 'i' } } 
    : {};
  try {
    const users = await User.find(filter);
    res.json({ users, searchTerm });
  } catch (err) {
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// View all posts
exports.viewAllPosts = async (req, res) => {
  const searchTerm = req.query.search || ''; 
  const filter = searchTerm
    ? {
        $or: [
          { title: { $regex: searchTerm, $options: 'i' } }, 
          { tags: { $regex: searchTerm, $options: 'i' } }, 
        ],
      }
    : {};
  try {
    const posts = await Post.find(filter).populate('createdBy', 'username');
    res.json({ posts, searchTerm });
  } catch (err) {
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};

// Delete post
exports.deletePost = async (req, res) => {
  try {
    await Post.findByIdAndDelete(req.params.id);
    res.json({ message: 'Post deleted successfully' });
  } catch (err) {
    res.status(500).json({
      error: 'Server error, please try again later',
    });
  }
};