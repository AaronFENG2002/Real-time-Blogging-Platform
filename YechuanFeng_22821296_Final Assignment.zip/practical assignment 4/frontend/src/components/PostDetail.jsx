import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Container, Card, Button, Spinner, Alert, Badge, Modal } from 'react-bootstrap';

function PostDetail() {
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const { id } = useParams();
  const navigate = useNavigate();
  const currentUser = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchPost = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await axios.get(`/api/posts/${id}`);
        setPost(response.data.post);
      } catch (err) {
        setError('Failed to fetch post details. It might have been deleted or the link is incorrect.');
        console.error("Fetch post detail error:", err);
      }
      setLoading(false);
    };
    fetchPost();
  }, [id]);

  const handleDelete = async () => {
    setShowDeleteModal(false); // Close modal first
    try {
      await axios.post(`/api/posts/${id}/delete`);
      // alert('Post deleted successfully'); // Consider using a more subtle notification
      navigate('/posts'); 
    } catch (err) {
      setError('Failed to delete post. Please try again.');
      console.error("Delete post error:", err);
      // alert('Failed to delete post');
    }
  };

  const openDeleteModal = () => setShowDeleteModal(true);
  const closeDeleteModal = () => setShowDeleteModal(false);

  if (loading) {
    return (
      <Container className="text-center mt-5">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
        <p>Loading post...</p>
      </Container>
    );
  }

  if (error && !post) { // Show error prominently if post couldn't be loaded
    return <Container className="mt-3"><Alert variant="danger">{error}</Alert></Container>;
  }
  
  if (!post) { // Fallback if no post and no specific error (should ideally be caught by error state)
    return <Container className="mt-3"><Alert variant="warning">Post not found.</Alert></Container>;
  }

  const isOwner = currentUser && post.createdBy && currentUser._id === post.createdBy._id;
  const isAdmin = currentUser && currentUser.isAdmin;

  return (
    <>
      {error && <Alert variant="danger" onClose={() => setError('')} dismissible className="mb-3">{error}</Alert>} {/* Show error for delete failure etc. */}
      <Card>
        <Card.Header as="h2">{post.title}</Card.Header>
        <Card.Body>
          <Card.Subtitle className="mb-2 text-muted">
            By: {post.createdBy ? 
              <Link to={`/user/${post.createdBy._id}/profile`}>{post.createdBy.username}</Link> : 
              'Unknown'}
            {' | '}Created: {new Date(post.createdAt).toLocaleString()}
          </Card.Subtitle>
          
          {post.tags && post.tags.length > 0 && (
            <div className="mb-3">
              Tags: {post.tags.map(tag => <Badge bg="secondary" key={tag} className="me-1">{tag}</Badge>)}
            </div>
          )}
          
          <Card.Text style={{ whiteSpace: 'pre-wrap' }}>{post.content}</Card.Text>
          
          {(isOwner || isAdmin) && (
            <div className="mt-3">
              <Button as={Link} to={`/posts/${id}/edit`} variant="outline-primary" className="me-2">Edit Post</Button>
              <Button variant="outline-danger" onClick={openDeleteModal}>Delete Post</Button>
            </div>
          )}
        </Card.Body>
        <Card.Footer>
          <Link to="/posts">Back to all posts</Link>
        </Card.Footer>
      </Card>

      <Modal show={showDeleteModal} onHide={closeDeleteModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>Are you sure you want to delete the post titled "<strong>{post.title}</strong>"? This action cannot be undone.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeDeleteModal}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete Post
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default PostDetail; 