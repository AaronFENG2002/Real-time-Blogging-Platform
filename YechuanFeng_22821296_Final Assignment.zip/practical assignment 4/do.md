COMP6006: Final Assignment (Part A)
A Real-time Blogging Platform
Total Marks: 45
Deadline: 5pm 26th May 2025
Overview
In this assignment, you will extend your practical assignment project to build a complete full-stack blogging 
platform. Your task is to modernize the existing blog application by:
• Replacing the original Pug frontend entirely with React.js
• Adding Google OAuth authentication using Passport.js
• Implementing a real-time pub/sub notification system using Socket.io
• Allowing users to subscribe/unsubscribe to authors and receive live post notifications
• Ensuring missed notifications are displayed after login
You must demonstrate your submitted work in person during the final examination week. During the 
demonstration, you will be required to answer questions related to your project and explain your source code. 
Failure to demonstrate adequate understanding may result in a deduction of marks.
Assignment Objectives and Mark Distribution
1. React Frontend with React-Bootstrap (20 marks)
Build a responsive single-page application (SPA) using React.js and React-Bootstrap.
Frontend Requirements:
• Setup:
o Use create-react-app or Vite
o Style all UI components with React-Bootstrap
• Login/Register Page:
o Support both local and Google login
o Provide frontend validation for user input
o Redirect users to the homepage after login
o Hint: You can use React Router for routing and context or local storage for managing login state.
• Home / Post List Page:
o Display all blog posts with title, tags, author name (linked), and a preview
o Each post should be clickable to view its details
o Include a search bar to filter posts by title or tags (right panel)
o Include a list of active users in the blog on the left side panel. When a user clicks on the username, 
they should be redirected to the author’s page.
• Post Detail Page:
o Display the full content of a post
o Author's name should be clickable, linking to their profile
o If the viewer is the post’s author, show Edit and Delete buttons
o Display a Subscribe/Unsubscribe button next to the author’s name
o Hint: You can reuse the Author Profile component for the redirection.
• Author Profile Page:
o List all blog posts authored by the selected user
o Display author's name and total post count
o Include a Subscribe/Unsubscribe button at the top
o When a user visits their own page, they should see their own posts and have the option to edit 
or delete each post.
• Post Editor Page:
o Allow authenticated users to create and edit only their own posts
• Subscription Management Page:
o Display a list of authors the current user is subscribed to
o Each item should include:
 Author’s name (linked to their profile)
 An Unsubscribe button
• Navigation Bar:
o Display the logged-in user’s name and (if available) Google profile image. If the user is not logged 
in, display the log-in and sign-up button.
o Bell icon with badge count for notifications
o Dropdown list showing recent notifications
o Search bar (if not on homepage)
o Navigation links: Home, New Post, Subscriptions, Logout
2. Authentication – Google OAuth (5 marks)
Implement Google login using Passport.js. Marks are awarded only for this functionality.
Requirements:
• Use the passport-google-oauth20 strategy
• Store user details including:
o Google ID
o Display name
o Email address
o Profile picture URL
• Local login functionality must be reused from the original assignment (no additional marks)
• On successful login, redirect users to the homepage
Helpful Resources:
• Passport Google OAuth20 Strategy Docs
• Google Developer Console: create credentials for OAuth client
Hint: Use environment variables for storing client ID and secret securely.
3. Blog Post Management (Backend: 0 marks)
The backend logic for blog post creation, editing, viewing, and deletion should be reused from the original 
assignment.
Note: If your backend APIs are broken or missing, frontend features depending on them cannot be tested, and 
marks from the frontend section may be deducted accordingly.
Hint: Ensure routes like GET /posts, GET /posts/:id, POST /posts, and PUT/DELETE /posts/:id are functional.
4. Real-Time Notification System with Socket.io (20 marks)
Use Socket.io to implement a real-time notification system for post subscriptions.
Requirements:
• Subscription Logic:
o Authenticated users can subscribe or unsubscribe to any other user
o Store subscriptions in the following schema:
{
 subscriberId: ObjectId,
 targetUserId: ObjectId
}
• Real-Time Notification Delivery:
o When a user publishes a new post, all online subscribers should receive a real-time notification
o Only authenticated users should be allowed to connect to the socket server (use JWT or session 
validation)
o Hint: Emit a new_post event to all sockets subscribed to the post author.
• Notification UI:
o Display a bell icon in the navbar with a badge showing the count of unseen notifications
o Clicking the bell shows a dropdown with the following details:
 Post title
 Author name
 Relative timestamp (e.g., “2 minutes ago”)
 A clickable link to view the post
o Opening the dropdown should mark notifications as seen and clear the badge
• Missed Notifications:
o Upon successful login, users should automatically receive a list of missed (unseen) 
notifications that were generated while they were offline.
o These notifications should be retrieved from the backend using an authenticated API call (e.g., 
GET /notifications).
o Integrate the result with the notification dropdown used for live events.
o Use timestamps to sort and render the latest ones first.
Hint:
Create a Notification model with at least the following fields:
{
 recipientId: ObjectId,
 postId: ObjectId,
 seen: Boolean,
 createdAt: Date
}
• On post creation, notify online subscribers via Socket.io and store a new notification for all subscribers in the 
database.
• When a user logs in, fetch all unseen notifications and display them in the dropdown.
• Use a field like seen = true/false and update it when the user opens the dropdown.
Extra Hint: Consider creating a PATCH /notifications/mark-seen endpoint to mark them as read.
Tech Stack Requirements
• Backend: Node.js, Express.js, MongoDB (Mongoose)
• Authentication: Passport.js (Local + Google OAuth)
• Frontend: React.js with React-Bootstrap
• Real-Time Communication: Socket.io
• Security: Only authenticated users should be allowed to perform restricted actions such as posting, 
subscribing, or accessing notifications
Submission Guidelines
• Submit your assignment as a .zip file via Blackboard.
• The zip file must include all frontend and backend source code.
• Do not include the node_modules/ folder in your submission.
• Ensure your application can be set up correctly with npm install and runs without error.
• All submitted work must be your own. Academic integrity rules apply.